<?php
	$con=mysqli_connect("localhost","root","","multistep_form");
	if (!$con) {
		echo "not connected";
	}
	$fname=$_POST['a1'];
	$lname=$_POST['a2'];
	$phone=$_POST['a3'];
	$address=$_POST['a4'];
	$state=$_POST['a5'];
	$city=$_POST['a6'];
	$email=$_POST['a7'];
	$pass=$_POST['a8'];
	$check="SELECT * FROM user_data where email='$email'";
	$result=mysqli_query($con,$check);
	if (mysqli_num_rows($result)==1) {
		echo "username already available.....!!";
	}
	else{
		$query="INSERT INTO user_data(first_name,last_name,phone,address,state,city,email,password) VALUES('$fname','$lname','$phone','$address','$state','$city','$email','$pass')";
		$res=mysqli_query($con,$query);
		if ($res) {
			echo "Successfully data inserted";
		}
		else{
			echo "something wrong...";
		}
	}

?>