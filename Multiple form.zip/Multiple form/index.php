<!DOCTYPE html>
<html lang="en">
<head>
  <title>Multiple form Submission</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  <style type="text/css">
  	p{
  		color: red;
  	}
  	#message{
  		background: #00C851;
  		padding: 10px;
  		color: #fff;
  		display: none;
  	}
  </style>
</head>
<body style="background: #00C851">
	<div class="container col-lg-6 m-auto">
		<div class="content">
			<div id="message"></div>
			<h3>User Registration Form</h3>
			<div class="progress">
				<div class="progress-bar" role="progressbar" id="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">Personal Info</div>
			</div>
			<form method="post">
				<div id="first-div">
					<input type="text" name="a1" id="fname" placeholder="First Name">
					<p id="fname-error"></p>
					<input type="text" name="a2" id="lname" placeholder="Last Name">
					<p id="lname-error"></p>
					<input type="text" name="a3" id="phone" placeholder="Phone No.">
					<p id="phone-error"></p>
					<a href="#" class="btn btn-danger" id="next-1">Next</a>
				</div>
				<div id="second-div">
					<textarea placeholder="Address" id="address" name="a4"></textarea>
					<p id="address-error"></p>
					<input type="text" name="a5" id="state" placeholder="State">
					<p id="state-error"></p>
					<input type="text" name="a6" id="city" placeholder="City">
					<p id="city-error"></p>
					<a href="#" class="btn btn-danger" id="previous-1">previous</a>
					<a href="#" class="btn btn-danger" id="next-2">Next</a>
				</div>
				<div id="third-div">
					<input type="email" name="a7" id="email" placeholder="E-mail">
					<p id="email-error"></p>
					<input type="password" name="a8" id="password" placeholder="password">
					<p id="password-error"></p>
					<a href="#" class="btn btn-danger" id="previous-2">previous</a>
					<input type="submit" name="submit" value="submit" id="submit" class="btn btn-success">
				</div>
			</form>
		</div>
	</div>



<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#next-1').click(function(e){
			e.preventDefault();
			$('#fname-error').html('');
			$('#lname-error').html('');
			$('#phone-error').html('');
			if ($('#fname').val()=='') {
				$('#fname-error').html("*first name is required..!!");
				return false;
			}
			else if ($('#fname').val().length < 3) {
				$('#fname-error').html("First name must be 3 or more character..!!");
				return false;
			}
			else if (!isNaN($('#fname').val())) {
				$('#fname-error').html("*Number is not allowed..!!");
				return false;
			}
			else if ($('#lname').val()=='') {
				$('#lname-error').html("*first name is required..!!");
				return false;
			}
			else if ($('#lname').val().length < 3) {
				$('#lname-error').html("First name must be 3 or more character..!!");
				return false;
			}
			else if (!isNaN($('#lname').val())) {
				$('#lname-error').html("*Number is not allowed..!!");
				return false;
			}
			else if ($('#phone').val()=='') {
				$('#phone-error').html("Phone no. is required..!!")
				return false;
			}
			else if (isNaN($('#phone').val())) {
				$('#phone-error').html("*only Number are allowed..!!");
				return false;
			}
			else if ($('#phone').val().length!=10) {
				$('#phone-error').html("*Phone no. must be of 10 digits..!!");
				return false;
			}

			else{
				$('#second-div').show();
				$('#first-div').hide();
				$('#progressbar').css('width','60%');
				$('#progressbar').html("Address Info");
			}

		});
		$('#next-2').click(function(e){
			e.preventDefault();

			$('#address-error').html('');
			$('#state-error').html('');
			$('#city-error').html('');

			if ($('#address').val()=='') {
				$('#address-error').html('*Address is required...!!');
				return false;
			}
			else if ($('#address').val().length < 10) {
				$('#address-error').html('*Address should be of 10 digits....!!');
				return false;
			}
			else if ($('#state').val()=='') {
				$('#state-error').html('*state is required...!!');
				return false;
			}
			else if (!isNaN($('#state').val())) {
				$('#state-error').html("*Number is not allowed..!!");
				return false;
			}
			else if ($('#city').val()=='') {
				$('#city-error').html('*city is required...!!');
				return false;
			}
			else if (!isNaN($('#city').val())) {
				$('#city-error').html("*Number is not allowed..!!");
				return false;
			}
			else{
				$('#second-div').hide();
				$('#third-div').show();
				$('#progressbar').css('width','100%');
				$('#progressbar').html("Email Info");
			}

		});
		$('#previous-1').click(function(){
			$('#first-div').show();
			$('#second-div').hide();
			$('#progressbar').css('width','25%');
			$('#progressbar').html("Personal Info");

		});
		$('#previous-2').click(function(){
			$('#third-div').hide();
			$('#second-div').show();
			$('#progressbar').css('width','60%');
			$('#progressbar').html("Address Info");

		});
		$('#submit').click(function(e){
			e.preventDefault();
			$('#email-error').html('');
			$('#password-error').html('');
			if ($('#email').val()=='') {
				$('#email-error').html('E-mail is required....!!');
				return false;
			}
			else if (!validateEmail($('#email').val())) {
				$('#email-error').html("Invalid Email...!!");
				return false();
			}
			else  if ($('#password').val()=='') {
				$('#password-error').html("password is required...!!");
				return false;
			}
			else  if ($('#password').val().length < 8) {
				$('#password-error').html("password must of 8 digit...!!");
				return false;
			}
			else{
				$.ajax({
					url:'user_data.php',
					method:'post',
					data:$('form').serialize(),
					dataType:"text",
					success:function(strMessage){
						$('#message').show();
						$('#message').text(strMessage);
					}
				});
			}


			function validateEmail($email){
				var emailReg=/^([a-zA-Z0-9_\.\_\+])+\@(([a-zA-Z0-9])+\.)+([a-zA-Z0-9]{2,4})+$/;
				return emailReg.test($email);
			}
		});
	});
</script>
</body>
</html>